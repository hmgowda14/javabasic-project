package com.java;
import java.util.Scanner;

public class MovieTicketBooking {

    static Scanner sc = new Scanner(System.in);

    static boolean seats[][] = new boolean[5][5];

    static double totalAmount = 0;

    public static void main(String[] args) {

        int choice;

        do {

            System.out.println("========= MOVIE TICKET BOOKING SYSTEM =========");
            System.out.println("1. Show Available Seats");
            System.out.println("2. Book Ticket");
            System.out.println("3. Cancel Ticket");
            System.out.println("4. Apply Discount Coupon");
            System.out.println("5. Weekend Pricing");
            System.out.println("6. Give Movie Rating");
            System.out.println("7. Exit");
            System.out.print("Enter your choice : ");

            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    showSeats();
                    break;

                case 2:
                    bookTicket();
                    break;

                case 3:
                    cancelTicket();
                    break;

                case 4:
                    applyCoupon();
                    break;

                case 5:
                    weekendPricing();
                    break;

                case 6:
                    movieRating();
                    break;

                case 7:
                    System.out.println("Thank You! Visit Again.");
                    break;

                default:
                    System.out.println("Invalid Choice");
            }

        } while (choice != 7);

        sc.close();
    }


    static void showSeats() {

        System.out.println("Seat Layout");
        System.out.println("A = Available");
        System.out.println("B = Booked");

        for (int i = 0; i < seats.length; i++) {

            for (int j = 0; j < seats[i].length; j++) {

                if (seats[i][j])
                    System.out.print(" B ");
                else
                    System.out.print(" A ");

            }

            System.out.println();
        }

    }

    static void bookTicket() {

        showSeats();

        System.out.print("Enter Row (1-5): ");
        int row = sc.nextInt();

        System.out.print("Enter Seat (1-5): ");
        int seat = sc.nextInt();

        if (row < 1 || row > 5 || seat < 1 || seat > 5) {

            System.out.println("Invalid Seat Number.");
            return;
        }

        if (seats[row - 1][seat - 1]) {

            System.out.println("Seat Already Booked.");

        } else {

            seats[row - 1][seat - 1] = true;
            totalAmount += 200;

            System.out.println("Ticket Booked Successfully.");
            System.out.println("Ticket Price : Rs.200");
        }

    }

    static void cancelTicket() {

        System.out.print("Enter Row: ");
        int row = sc.nextInt();

        System.out.print("Enter Seat: ");
        int seat = sc.nextInt();

        if (row < 1 || row > 5 || seat < 1 || seat > 5) {

            System.out.println("Invalid Seat.");
            return;
        }

        if (seats[row - 1][seat - 1]) {

            seats[row - 1][seat - 1] = false;
            totalAmount -= 200;

            System.out.println("Ticket Cancelled Successfully.");

        } else {

            System.out.println("Seat is already available.");

        }

    }

    static void applyCoupon() {

        sc.nextLine();

        System.out.print("Enter Coupon Code: ");
        String coupon = sc.nextLine();

        if (coupon.equalsIgnoreCase("SAVE20")) {

            totalAmount = totalAmount * 0.80;
            System.out.println("20% Discount Applied.");

        } else {

            System.out.println("Invalid Coupon.");

        }

        System.out.println("Total Amount : Rs." + totalAmount);

    }

    static void weekendPricing() {

        sc.nextLine();

        System.out.print("Is Today Saturday or Sunday? (Yes/No): ");
        String day = sc.nextLine();

        if (day.equalsIgnoreCase("Yes")) {

            totalAmount += 100;

            System.out.println("Weekend Charges Added.");
            System.out.println("Total Amount : Rs." + totalAmount);

        } else {

            System.out.println("Normal Ticket Price.");
            System.out.println("Total Amount : Rs." + totalAmount);

        }

    }

    static void movieRating() {

        System.out.print("Rate Movie (1-5): ");
        int rating = sc.nextInt();

        if (rating == 5)
            System.out.println("Excellent Movie!");
        else if (rating == 4)
            System.out.println("Very Good!");
        else if (rating == 3)
            System.out.println("Good Movie.");
        else if (rating == 2)
            System.out.println("Average Movie.");
        else if (rating == 1)
            System.out.println("Poor Movie.");
        else
            System.out.println("Invalid Rating.");

    }

}
