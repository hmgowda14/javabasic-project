package com.java;
import java.util.HashMap;
import java.util.Scanner;

class User {
    String username;
    String password;

    User(String username, String password) {
        this.username = username;
        this.password = password;
    }
}

public class OnlineVotingSystem {

    static Scanner sc = new Scanner(System.in);

    static HashMap<String, User> users = new HashMap<>();

    static HashMap<String, Boolean> voted = new HashMap<>();


    static HashMap<String, Integer> candidateVotes = new HashMap<>();

    static String currentUser = "";

    public static void main(String[] args) {

        candidateVotes.put("Rahul", 0);
        candidateVotes.put("Ananya", 0);
        candidateVotes.put("Kiran", 0);

        int choice;

        do {

            System.out.println("========== COLLEGE ONLINE VOTING SYSTEM ==========");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Display Candidates");
            System.out.println("4. Cast Vote");
            System.out.println("5. View Vote Count");
            System.out.println("6. Display Winner");
            System.out.println("7. Display Runner-Up");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:
                    registerUser();
                    break;

                case 2:
                    loginUser();
                    break;

                case 3:
                    showCandidates();
                    break;

                case 4:
                    vote();
                    break;

                case 5:
                    showVotes();
                    break;

                case 6:
                    showWinner();
                    break;

                case 7:
                    showRunnerUp();
                    break;

                case 8:
                    System.out.println("Thank you for using the Online Voting System.");
                    break;

                default:
                    System.out.println("Please enter a valid choice.");
            }

        } while (choice != 8);

        sc.close();
    }

    static void registerUser() {

        System.out.print("Enter Username: ");
        String username = sc.nextLine();

        if (users.containsKey(username)) {
            System.out.println("Username already exists.");
            return;
        }

        System.out.print("Enter Password: ");
        String password = sc.nextLine();

        users.put(username, new User(username, password));
        voted.put(username, false);

        System.out.println("Registration Successful.");
    }

    // Login
    static void loginUser() {

        System.out.print("Enter Username: ");
        String username = sc.nextLine();

        System.out.print("Enter Password: ");
        String password = sc.nextLine();

        if (users.containsKey(username)
                && users.get(username).password.equals(password)) {

            currentUser = username;
            System.out.println("Login Successful.");

        } else {

            System.out.println("Invalid Username or Password.");
        }
    }


    static void showCandidates() {

        System.out.println("----- Candidate List -----");
        System.out.println("Rahul");
        System.out.println("Ananya");
        System.out.println("Kiran");
    }

    static void vote() {

        try {

            if (currentUser.equals("")) {
                throw new Exception("Please login first.");
            }

            if (voted.get(currentUser)) {
                throw new Exception("You have already voted.");
            }

            showCandidates();

            System.out.print("Enter Candidate Name: ");
            String candidate = sc.nextLine();

            if (!candidateVotes.containsKey(candidate)) {
                throw new Exception("Candidate not found.");
            }

            int total = candidateVotes.get(candidate);
            candidateVotes.put(candidate, total + 1);

            voted.put(currentUser, true);

            System.out.println("Your vote has been recorded successfully.");

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }
    }

    static void showVotes() {

        System.out.println("----- Vote Count -----");

        for (String name : candidateVotes.keySet()) {

            System.out.println(name + " : " + candidateVotes.get(name));

        }
    }

    static void showWinner() {

        String winner = "";
        int highestVotes = -1;

        for (String name : candidateVotes.keySet()) {

            if (candidateVotes.get(name) > highestVotes) {

                highestVotes = candidateVotes.get(name);
                winner = name;

            }

        }

        System.out.println("Winner : " + winner);
        System.out.println("Votes  : " + highestVotes);
    }


    static void showRunnerUp() {

        String winner = "";
        String runnerUp = "";

        int first = -1;
        int second = -1;

        for (String name : candidateVotes.keySet()) {

            int votes = candidateVotes.get(name);

            if (votes > first) {

                second = first;
                runnerUp = winner;

                first = votes;
                winner = name;

            } else if (votes > second) {

                second = votes;
                runnerUp = name;

            }

        }

        System.out.println("Runner-Up : " + runnerUp);
        System.out.println("Votes      : " + second);
    }
}