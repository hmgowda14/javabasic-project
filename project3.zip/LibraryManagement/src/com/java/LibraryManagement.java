package com.java;
import java.util.*;
import java.time.*;
import java.time.temporal.ChronoUnit;

class Book {

    int bookId;
    String bookName;
    String author;
    boolean available;

    LocalDate issueDate;
    LocalDate dueDate;

    Book(int bookId, String bookName, String author) {

        this.bookId = bookId;
        this.bookName = bookName;
        this.author = author;
        this.available = true;

    }

}

public class LibraryManagement {

    static Scanner sc = new Scanner(System.in);


    static ArrayList<Book> books = new ArrayList<>();

    static HashMap<String, Book> issuedBooks = new HashMap<>();

    public static void main(String[] args) {

        int choice;

        do {

            System.out.println("\n========== LIBRARY MANAGEMENT SYSTEM ==========");
            System.out.println("1. Add Book");
            System.out.println("2. Display Books");
            System.out.println("3. Search Book");
            System.out.println("4. Issue Book");
            System.out.println("5. Return Book");
            System.out.println("6. Book Availability");
            System.out.println("7. Fine Calculator");
            System.out.println("8. Due Date Reminder");
            System.out.println("9. Librarian Report");
            System.out.println("10. Exit");

            System.out.print("Enter your choice : ");
            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    addBook();
                    break;

                case 2:
                    displayBooks();
                    break;

                case 3:
                    searchBook();
                    break;

                case 4:
                    issueBook();
                    break;

                case 5:
                    returnBook();
                    break;

                case 6:
                    bookAvailability();
                    break;

                case 7:
                    fineCalculator();
                    break;

                case 8:
                    dueReminder();
                    break;

                case 9:
                    librarianReport();
                    break;

                case 10:
                    System.out.println("Thank You... Visit Again!");
                    break;

                default:
                    System.out.println("Invalid Choice.");

            }

        } while (choice != 10);

        sc.close();

    }


    static void addBook() {

        sc.nextLine();

        System.out.print("Enter Book Id : ");
        int id = Integer.parseInt(sc.nextLine());

        System.out.print("Enter Book Name : ");
        String name = sc.nextLine();

        System.out.print("Enter Author Name : ");
        String author = sc.nextLine();

        books.add(new Book(id, name, author));

        System.out.println("Book Added Successfully.");

    }

    static void displayBooks() {

        if (books.isEmpty()) {

            System.out.println("No Books Available.");
            return;

        }

        System.out.println("\n------------ BOOK LIST ------------");

        for (Book b : books) {

            System.out.println("Book Id      : " + b.bookId);
            System.out.println("Book Name    : " + b.bookName);
            System.out.println("Author       : " + b.author);
            System.out.println("Status       : " + (b.available ? "Available" : "Issued"));
            System.out.println("-----------------------------------");

        }

    }

    static void searchBook() {

        sc.nextLine();

        System.out.print("Enter Book Name : ");
        String search = sc.nextLine();

        boolean found = false;

        for (Book b : books) {

            if (b.bookName.equalsIgnoreCase(search)) {

                System.out.println("Book Found");
                System.out.println("Book Id : " + b.bookId);
                System.out.println("Author  : " + b.author);
                System.out.println("Status  : " + (b.available ? "Available" : "Issued"));

                found = true;

            }

        }

        if (!found) {

            System.out.println("Book Not Found.");

        }

    }

    static void issueBook() {

        try {

            sc.nextLine();

            System.out.print("Enter Student Name : ");
            String student = sc.nextLine();

            if (issuedBooks.containsKey(student)) {

                throw new Exception("Student has already issued a book.");

            }

            System.out.print("Enter Book Name : ");
            String book = sc.nextLine();

            for (Book b : books) {

                if (b.bookName.equalsIgnoreCase(book) && b.available) {

                    b.available = false;

                    b.issueDate = LocalDate.now();

                    b.dueDate = LocalDate.now().plusDays(7);

                    issuedBooks.put(student, b);

                    System.out.println("Book Issued Successfully.");
                    System.out.println("Issue Date : " + b.issueDate);
                    System.out.println("Due Date   : " + b.dueDate);

                    return;

                }

            }

            System.out.println("Book Not Available.");

        }

        catch (Exception e) {

            System.out.println(e.getMessage());

        }

    }

    static void returnBook() {

        sc.nextLine();

        System.out.print("Enter Student Name : ");
        String student = sc.nextLine();

        if (issuedBooks.containsKey(student)) {

            Book b = issuedBooks.get(student);

            b.available = true;

            issuedBooks.remove(student);

            System.out.println("Book Returned Successfully.");

        }

        else {

            System.out.println("No Book Issued for this Student.");

        }

    }

    static void bookAvailability() {

        System.out.println("Available Books");

        boolean available = false;

        for (Book b : books) {

            if (b.available) {

                System.out.println(b.bookName);

                available = true;

            }

        }

        if (!available) {

            System.out.println("No Books Available.");

        }

    }


    static void fineCalculator() {

        sc.nextLine();

        System.out.print("Enter Student Name : ");
        String student = sc.nextLine();

        if (issuedBooks.containsKey(student)) {

            Book b = issuedBooks.get(student);

            long days = ChronoUnit.DAYS.between(b.dueDate, LocalDate.now());

            if (days > 0) {

                long fine = days * 10;

                System.out.println("Late by " + days + " day(s).");
                System.out.println("Fine Amount : Rs." + fine);

            }

            else {

                System.out.println("No Fine. Book is within Due Date.");

            }

        }

        else {

            System.out.println("Student has not issued any book.");

        }

    }

    static void dueReminder() {

        if (issuedBooks.isEmpty()) {

            System.out.println("No Books Issued.");
            return;

        }

        System.out.println("-------- Due Date Reminder --------");

        for (String student : issuedBooks.keySet()) {

            Book b = issuedBooks.get(student);

            System.out.println("Student : " + student);
            System.out.println("Book    : " + b.bookName);
            System.out.println("Due Date: " + b.dueDate);
            System.out.println("-------------------------------");

        }

    }

    static void librarianReport() {

        System.out.println("========== LIBRARY REPORT ==========");

        System.out.println("Total Books        : " + books.size());

        System.out.println("Books Issued       : " + issuedBooks.size());

        System.out.println("Books Available    : " + (books.size() - issuedBooks.size()));

    }

}